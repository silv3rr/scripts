# TODO

Things that ~~might eventually~~ never get done.. or not :)

## foo-pre

- [ ] replace pre/mp3genre by pzs-ng code or other id3 lib instead (PR welcome)
- [x] add FLAC support (unlikely but PR's welcome)
- [x] add module: prebw after pre (mod_prebw)

