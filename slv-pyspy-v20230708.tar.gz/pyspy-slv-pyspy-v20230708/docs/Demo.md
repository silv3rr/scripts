# Demo

Select user and view details in cli:

![demo](demo.gif)

Download original [demo.cast](demo.cast)

made with [asciinema](https://asciinema.org) and [agg](https://github.com/asciinema/agg)
