# Modules

Addons for foo-pre; modules add functions but are not build into foo-pre binary

[README.modules](../README.modules)

- [README.mod_prebw](README.mod_prebw)
- [README.mod_audiosort](README.mod_audiosort)
- [README.mod_chmod](README.mod_chmod)
- [README.mod_idmp3](README.mod_idmp3)
- [README.mod_nfohandler](README.mod_nfohandler)
- [README.mod_sitenfoadd](README.mod_sitenfoadd)
- [README.mod_symlink](README.mod_symlink)

