# TODO

Things that might eventually get done.. or not :)

## foo-pre

- [ ] replace pre/mp3genre by pzs-ng code or other id3 lib instead
- [ ] add FLAC support (unlikely but PR's welcome)
- [ ] add module: prebw after pre (mod_prebw)

